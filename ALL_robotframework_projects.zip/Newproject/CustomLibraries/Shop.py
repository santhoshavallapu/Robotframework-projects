from robot.api.deco import library, keyword
from robot.libraries.BuiltIn import BuiltIn

#these annotation is to understand the robot that we are converting these class into library in robot file

@library
class Shop:
# constructor name is always init in python
    def __init__(self):
        #importing the selenium library in python file
        #we can pass any library instance library in the place of selenium library based on the requirement
        self.selLib=BuiltIn().get_library_instance("SeleniumLibrary")

    #method name will be converted to key word as Hello world
    #explicitly saying by the annotation that converting method to keyword
    @keyword
    def hello_world(self):
        print('hello')

    @keyword
    def add_items_to_cart_and_checkout(self, productslist):

        # @{elements}=   Get WebElements      css:.card - title
        #storing the products tiltles in the productTitle variable from the web page
        i = 1
        productTitles = self.selLib.get_webelements("css:.card - title")
        #iterating the items
        for productTitle in productTitles:
            #if the item of producttitle is match with item of product list then click on the add button
            if productTitle.text in productslist:
                self.selLib.click_button("xpath:(//*[@class='card-footer'])['+str(i)+']/button")

            i=i+1

                








